function MainController($scope, $http, $location){

 $scope.addUser = function($event){
   app.dataSoruce.insert(0, { name : "Test" });

   $($event.target).val("");
 };

}
